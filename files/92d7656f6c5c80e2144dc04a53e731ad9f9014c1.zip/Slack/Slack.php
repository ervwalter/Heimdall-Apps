<?php namespace App\SupportedApps\Slack;

class Slack extends \App\SupportedApps
{
}
