<ul class="livestats">
    <li>
        <span class="title">Monitors</span>
        <strong class="{!! $uptime_status !!}">{!! $checks_up !!}<span>/{!! $checks_total !!}</span></strong>
    </li>
</ul>
