<?php namespace App\SupportedApps\Wekan;

class Wekan extends \App\SupportedApps
{
}
