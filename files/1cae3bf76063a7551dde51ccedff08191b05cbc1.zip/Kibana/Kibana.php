<?php namespace App\SupportedApps\Kibana;

class Kibana extends \App\SupportedApps
{
}
