<?php namespace App\SupportedApps\UptimeKuma;

class UptimeKuma extends \App\SupportedApps
{
}
