<?php namespace App\SupportedApps\youtubedl;

class youtubedl extends \App\SupportedApps
{
}
