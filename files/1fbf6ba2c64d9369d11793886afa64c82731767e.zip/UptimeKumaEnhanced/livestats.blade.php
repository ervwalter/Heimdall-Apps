<ul class="livestats">
    <li>
        <span class="title">Monitors</span>
        <strong class="{!! $status !!}">{!! $checks_up !!}<span>/{!! $checks_total !!}</span></strong>
    </li>
</ul>
